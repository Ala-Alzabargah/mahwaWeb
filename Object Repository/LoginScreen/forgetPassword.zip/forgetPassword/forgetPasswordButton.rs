<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>forgetPasswordButton</name>
   <tag></tag>
   <elementGuidId>f29d2889-a1f0-4b0f-bc0e-0844f7f2d9c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(text(), 'هل نسيت كلمة السر؟') or contains(text(), 'Forgot Password?') or contains(text(), &quot;Mot de passe oublié ?&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(text(), 'هل نسيت كلمة السر؟') or contains(text(), 'Forgot Password?') or contains(text(), &quot;Mot de passe oublié ?&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
