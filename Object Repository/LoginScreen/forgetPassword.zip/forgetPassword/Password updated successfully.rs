<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Password updated successfully</name>
   <tag></tag>
   <elementGuidId>c88e76de-830f-4b74-b882-f582b090a85d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[text()='Password updated successfully' or contains(text(),'تم تعديل كلمة المرور بنجاح')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[text()='Password updated successfully' or contains(text(),'تم تعديل كلمة المرور بنجاح')]</value>
   </webElementProperties>
</WebElementEntity>
