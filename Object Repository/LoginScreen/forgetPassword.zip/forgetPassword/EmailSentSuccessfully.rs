<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>EmailSentSuccessfully</name>
   <tag></tag>
   <elementGuidId>650c7536-6d95-4322-b82d-358a7f9a28f4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[contains(@class,'forgetPasswordSuccess') and text()]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[contains(@class,'forgetPasswordSuccess') and text()]</value>
   </webElementProperties>
</WebElementEntity>
