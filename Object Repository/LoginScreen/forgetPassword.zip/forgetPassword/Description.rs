<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Description</name>
   <tag></tag>
   <elementGuidId>37acc6c8-50da-4a89-af40-cb651517932c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[contains(text(),'أدخل عنوان البريد الإلكتروني أو رقم الجوّال المستخدم في الدخول لحسابك للمتابعة') or contains(text(),'Enter the email or mobile number used to login to your account to continue')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[contains(text(),'أدخل عنوان البريد الإلكتروني أو رقم الجوّال المستخدم في الدخول لحسابك للمتابعة') or contains(text(),'Enter the email or mobile number used to login to your account to continue')]</value>
   </webElementProperties>
</WebElementEntity>
