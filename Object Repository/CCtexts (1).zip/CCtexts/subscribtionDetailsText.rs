<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>subscribtionDetailsText</name>
   <tag></tag>
   <elementGuidId>6242a97b-2ab6-4574-b286-09815e84ffd7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[contains(text(), 'Subscription Details:') or contains(text(), &quot;Détails de l'abonnement:&quot;) or contains(text(), 'معلومات الاشتراك:')])</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[contains(text(), 'Subscription Details:') or contains(text(), &quot;Détails de l'abonnement:&quot;) or contains(text(), 'معلومات الاشتراك:')])</value>
   </webElementProperties>
</WebElementEntity>
