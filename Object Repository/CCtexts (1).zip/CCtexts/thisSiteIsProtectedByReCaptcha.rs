<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>thisSiteIsProtectedByReCaptcha</name>
   <tag></tag>
   <elementGuidId>cdface98-7bb1-4fa6-85f0-bec1f1b78f73</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[contains(text(), &quot;Ce site Internet est protégé par reCAPTCHA. Pour en savoir plus, rendez-vous&quot;) or contains(text(), 'This site is protected by reCAPTCHA. To find out more details, please visit') or contains(text(), 'هذا الموقع محمي من خلال reCAPTCHA لمعرفة المزيد يمكنك زيارة')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[contains(text(), &quot;Ce site Internet est protégé par reCAPTCHA. Pour en savoir plus, rendez-vous&quot;) or contains(text(), 'This site is protected by reCAPTCHA. To find out more details, please visit') or contains(text(), 'هذا الموقع محمي من خلال reCAPTCHA لمعرفة المزيد يمكنك زيارة')]</value>
   </webElementProperties>
</WebElementEntity>
