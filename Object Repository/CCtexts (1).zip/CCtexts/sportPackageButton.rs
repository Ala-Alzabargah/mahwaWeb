<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>sportPackageButton</name>
   <tag></tag>
   <elementGuidId>dd84cb7a-ae80-4af6-9edf-bccb0a12235d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[contains(text(), 'اختر الباقة') or contains(text(), 'Choisir') or contains(text(), 'Select')])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[contains(text(), 'اختر الباقة') or contains(text(), 'Choisir') or contains(text(), 'Select')])[4]</value>
   </webElementProperties>
</WebElementEntity>
