<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>expiryDate</name>
   <tag></tag>
   <elementGuidId>da279f5d-5304-47b1-ba66-5a0a4743d897</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[contains(@id, 'checkout-frames-expiry-date')])</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[contains(@id, 'checkout-frames-expiry-date')])</value>
   </webElementProperties>
</WebElementEntity>
