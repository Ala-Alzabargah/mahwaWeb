<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>activeCouponButton</name>
   <tag></tag>
   <elementGuidId>b75b877b-869b-4e99-84e1-f8666b574833</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[contains(text(), 'فعّل') or contains(text(), 'Activer') or contains(text(), 'Activate')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[contains(text(), 'فعّل') or contains(text(), 'Activer') or contains(text(), 'Activate')]</value>
   </webElementProperties>
</WebElementEntity>
