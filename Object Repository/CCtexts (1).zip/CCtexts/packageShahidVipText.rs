<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>packageShahidVipText</name>
   <tag></tag>
   <elementGuidId>cb10c8ea-b9e6-45f8-bdae-3f1e0249c4d5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(@class, 'SubscriptionDetails')])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(@class, 'SubscriptionDetails')])[1]</value>
   </webElementProperties>
</WebElementEntity>
