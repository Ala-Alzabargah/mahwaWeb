<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>pleaseEnterYourCardDetailsText</name>
   <tag></tag>
   <elementGuidId>078d0671-0099-4b3f-8807-9f774496b67c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[contains(text(), 'Please enter your card details') or contains(text(), &quot;Prière de saisir les informations de votre carte&quot;) or contains(text(), 'ادخل معلومات بطاقتك المصرفية')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[contains(text(), 'Please enter your card details') or contains(text(), &quot;Prière de saisir les informations de votre carte&quot;) or contains(text(), 'ادخل معلومات بطاقتك المصرفية')]</value>
   </webElementProperties>
</WebElementEntity>
