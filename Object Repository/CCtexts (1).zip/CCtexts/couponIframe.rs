<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>couponIframe</name>
   <tag></tag>
   <elementGuidId>c358cb7c-679d-4b1f-bba3-d8bd62add6bf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'shahid-checkout-redirection-iframe']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>shahid-checkout-redirection-iframe</value>
   </webElementProperties>
</WebElementEntity>
