<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>subscribeNowButton</name>
   <tag></tag>
   <elementGuidId>5c7b413b-86c8-4e74-b074-a4889b3154c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(text(), 'اشترك الآن') or contains(text(), 'Join now') or contains(text(), &quot;Abonnez-vous&quot;)])</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(text(), 'اشترك الآن') or contains(text(), 'Join now') or contains(text(), &quot;Abonnez-vous&quot;)])</value>
   </webElementProperties>
</WebElementEntity>
