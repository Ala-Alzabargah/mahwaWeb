<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ccIcon</name>
   <tag></tag>
   <elementGuidId>abf520da-d181-4213-a982-fad16ad20d64</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//img[contains(@class, 'imageIcon_icon')][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//img[contains(@class, 'imageIcon_icon')][1]</value>
   </webElementProperties>
</WebElementEntity>
