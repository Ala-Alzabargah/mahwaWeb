<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>couponVerificationMessageInvalid</name>
   <tag></tag>
   <elementGuidId>2b812d71-67fe-4094-97c3-21a2309d0932</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[contains(text(), 'قسيمة الخصم المزوّدة غير صحيحة أو منتهية الصلاحية.') or contains(text(), 'The provided coupon code is invalid or expired.') or contains(text(), &quot;Le code fourni n'est pas valide ou a expiré.&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[contains(text(), 'قسيمة الخصم المزوّدة غير صحيحة أو منتهية الصلاحية.') or contains(text(), 'The provided coupon code is invalid or expired.') or contains(text(), &quot;Le code fourni n'est pas valide ou a expiré.&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
