<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cardInformationIsVerifiedText</name>
   <tag></tag>
   <elementGuidId>e8c43731-7462-4ba6-b072-d95b525bd726</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//p[contains(text(), &quot;Les données de cette carte ont été vérifiées&quot;) or contains(text(), 'Card information is verified') or contains(text(), 'يتم التحقق من معلومات البطاقة')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//p[contains(text(), &quot;Les données de cette carte ont été vérifiées&quot;) or contains(text(), 'Card information is verified') or contains(text(), 'يتم التحقق من معلومات البطاقة')]</value>
   </webElementProperties>
</WebElementEntity>
