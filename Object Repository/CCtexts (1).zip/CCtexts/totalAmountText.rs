<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>totalAmountText</name>
   <tag></tag>
   <elementGuidId>4fbd9720-22f4-4211-b1d2-75cb459215dc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//label[contains(text(), 'Total Amount') or contains(text(), 'Total') or contains(text(), 'المجموع')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//label[contains(text(), 'Total Amount') or contains(text(), 'Total') or contains(text(), 'المجموع')]</value>
   </webElementProperties>
</WebElementEntity>
