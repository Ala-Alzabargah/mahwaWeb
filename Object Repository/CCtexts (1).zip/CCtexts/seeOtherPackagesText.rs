<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>seeOtherPackagesText</name>
   <tag></tag>
   <elementGuidId>5694cc10-9a41-4fbf-b157-3e591d5fd067</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(text(), 'See other packages') or contains(text(), 'المزيد من الباقات') or contains(text(),  'Autres forfaits')])</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(text(), 'See other packages') or contains(text(), 'المزيد من الباقات') or contains(text(),  'Autres forfaits')])</value>
   </webElementProperties>
</WebElementEntity>
