<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>doYouHaveAcouponCode</name>
   <tag></tag>
   <elementGuidId>f3eb4bf7-357b-4f8d-a0f9-30f9b01e4a05</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[contains(text(), 'Do you have a coupon code?') or contains(text(), &quot;Avez-vous un code de réduction ?&quot;) or contains(text(), 'هل لديك قسيمة خصم؟')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[contains(text(), 'Do you have a coupon code?') or contains(text(), &quot;Avez-vous un code de réduction ?&quot;) or contains(text(), 'هل لديك قسيمة خصم؟')]</value>
   </webElementProperties>
</WebElementEntity>
