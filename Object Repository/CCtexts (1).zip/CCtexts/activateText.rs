<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>activateText</name>
   <tag></tag>
   <elementGuidId>1f1471f6-9bd2-431f-a252-e11768c5dcc0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[contains(text(), 'فعّل') or contains(text(), 'Activate') or contains(text(), 'Activer')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[contains(text(), 'فعّل') or contains(text(), 'Activate') or contains(text(), 'Activer')]</value>
   </webElementProperties>
</WebElementEntity>
