<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>subscribtionText</name>
   <tag></tag>
   <elementGuidId>69b9d9e0-3469-4a31-8efb-224e01242778</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//label[contains(text(), 'الاشتراك') or contains(text(), 'Plan')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//label[contains(text(), 'الاشتراك') or contains(text(), 'Plan')]</value>
   </webElementProperties>
</WebElementEntity>
