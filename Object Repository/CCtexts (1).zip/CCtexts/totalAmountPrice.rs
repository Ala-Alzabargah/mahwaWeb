<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>totalAmountPrice</name>
   <tag></tag>
   <elementGuidId>094b54e9-5bc9-4cec-b7b8-71c589eb33fc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(@class, 'SubscriptionDetails_titleProduct__1y0Dp')])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(@class, 'SubscriptionDetails_titleProduct__1y0Dp')])[3]</value>
   </webElementProperties>
</WebElementEntity>
