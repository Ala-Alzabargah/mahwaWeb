<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chooseYourPackageIcon</name>
   <tag></tag>
   <elementGuidId>f8b6149b-578e-4185-ac7f-bd9d29d3e246</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//img[contains(@class, 'false navigationLink_icon')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//img[contains(@class, 'false navigationLink_icon')]</value>
   </webElementProperties>
</WebElementEntity>
