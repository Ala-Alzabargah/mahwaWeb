<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chooseYourPackageText</name>
   <tag></tag>
   <elementGuidId>ebabfc9f-1bc6-4c4e-9330-4c402ea1d25c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[contains(text(), &quot;Choisir un autre package&quot;) or contains(text(), 'Choose another package') or contains(text(), 'اختر باقة أخرى')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[contains(text(), &quot;Choisir un autre package&quot;) or contains(text(), 'Choose another package') or contains(text(), 'اختر باقة أخرى')]</value>
   </webElementProperties>
</WebElementEntity>
