<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SubscriptionCongratsTitle</name>
   <tag></tag>
   <elementGuidId>294f67ad-eeed-4275-9cf0-ff7ba04330f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'SubscriptionCongrats_') and contains(@class,'formTitle_form-title__')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'SubscriptionCongrats_') and contains(@class,'formTitle_form-title__')]</value>
   </webElementProperties>
</WebElementEntity>
