<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>checkoutCheckingMessage</name>
   <tag></tag>
   <elementGuidId>ce6ad39b-d3e7-4737-92ba-82f1b5b6a59c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'checkoutSuccess_message')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>checkoutSuccess_message</value>
   </webElementProperties>
</WebElementEntity>
