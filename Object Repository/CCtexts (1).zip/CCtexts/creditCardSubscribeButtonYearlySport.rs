<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>creditCardSubscribeButtonYearlySport</name>
   <tag></tag>
   <elementGuidId>59fb0a45-0b98-4bf7-889f-727e1ec30276</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//button[contains(text(),'Subscribe') or contains(text(), 'اشترك') or contains(text(), &quot;S’abonner&quot;)])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//button[contains(text(),'Subscribe') or contains(text(), 'اشترك') or contains(text(), &quot;S’abonner&quot;)])[2]</value>
   </webElementProperties>
</WebElementEntity>
