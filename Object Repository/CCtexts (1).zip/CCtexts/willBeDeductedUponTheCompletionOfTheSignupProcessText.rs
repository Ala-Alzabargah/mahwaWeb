<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>willBeDeductedUponTheCompletionOfTheSignupProcessText</name>
   <tag></tag>
   <elementGuidId>607dd28b-3153-4087-9d41-da6ace03a66a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[contains(@class, 'checkoutCard_disclaimer-text__1AYsd')])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[contains(@class, 'checkoutCard_disclaimer-text__1AYsd')])[1]</value>
   </webElementProperties>
</WebElementEntity>
