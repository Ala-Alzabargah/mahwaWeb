<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>oneStepForUnlimitedEntertainmentText</name>
   <tag></tag>
   <elementGuidId>a2bd5640-a76c-4210-bea7-268eeae97460</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h1[contains(text(), 'أنت على بعد خطوة واحدة من الترفيه بلا حدود') or contains(text(), &quot;Vous êtes sur le point de profiter de divertissements illimités&quot;) or contains(text(), 'You are one step away from unlimited entertainment')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h1[contains(text(), 'أنت على بعد خطوة واحدة من الترفيه بلا حدود') or contains(text(), &quot;Vous êtes sur le point de profiter de divertissements illimités&quot;) or contains(text(), 'You are one step away from unlimited entertainment')]</value>
   </webElementProperties>
</WebElementEntity>
