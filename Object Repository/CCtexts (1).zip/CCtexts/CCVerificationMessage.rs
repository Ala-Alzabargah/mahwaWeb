<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CCVerificationMessage</name>
   <tag></tag>
   <elementGuidId>66f1c41f-fb9d-45ab-a6f4-4d9216ea4894</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[contains(@class, 'toast-notification')])</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[contains(@class, 'toast-notification')])</value>
   </webElementProperties>
</WebElementEntity>
