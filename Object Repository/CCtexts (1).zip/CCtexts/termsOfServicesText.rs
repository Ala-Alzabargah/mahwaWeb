<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>termsOfServicesText</name>
   <tag></tag>
   <elementGuidId>56f31193-7d15-47ef-a23d-f426b3ac477e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(text(), &quot;Conditions d’utilisation&quot;) or contains(text(), 'Terms of service') or contains(text(), 'شروط الخدمة')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(text(), &quot;Conditions d’utilisation&quot;) or contains(text(), 'Terms of service') or contains(text(), 'شروط الخدمة')]</value>
   </webElementProperties>
</WebElementEntity>
