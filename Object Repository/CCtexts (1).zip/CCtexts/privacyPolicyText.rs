<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>privacyPolicyText</name>
   <tag></tag>
   <elementGuidId>13f73c04-8335-409e-be5f-3ab9ca9d05c8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[contains(text(), &quot;Politique de confidentialité&quot;) or contains(text(), 'Privacy policy') or contains(text(), 'سياسة الخصوصية')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(text(), &quot;Politique de confidentialité&quot;) or contains(text(), 'Privacy policy') or contains(text(), 'سياسة الخصوصية')]</value>
   </webElementProperties>
</WebElementEntity>
