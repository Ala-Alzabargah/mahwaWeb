<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cvvCreditCard</name>
   <tag></tag>
   <elementGuidId>7197052a-3206-47e1-9ddc-14fb632ff6b8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//input[contains(@id, 'checkout-frames-cvv')])</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[contains(@id, 'checkout-frames-cvv')])</value>
   </webElementProperties>
</WebElementEntity>
