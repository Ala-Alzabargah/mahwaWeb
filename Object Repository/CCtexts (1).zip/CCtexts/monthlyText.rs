<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>monthlyText</name>
   <tag></tag>
   <elementGuidId>41866408-f411-4cce-b543-efcc64ad8339</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(@class, 'SubscriptionDetails_titleProduct')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(@class, 'SubscriptionDetails_titleProduct')])[2]</value>
   </webElementProperties>
</WebElementEntity>
