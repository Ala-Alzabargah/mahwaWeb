<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>package</name>
   <tag></tag>
   <elementGuidId>f42a2f94-242d-4547-904c-d0c1d979e8da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//label[contains(text(), 'الباقة') or contains(text(), 'Forfait') or contains(text(), 'Package')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//label[contains(text(), 'الباقة') or contains(text(), 'Forfait') or contains(text(), 'Package')]</value>
   </webElementProperties>
</WebElementEntity>
