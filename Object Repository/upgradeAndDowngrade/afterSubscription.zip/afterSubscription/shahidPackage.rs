<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>shahidPackage</name>
   <tag></tag>
   <elementGuidId>aa6771da-2c95-4cb9-954a-308e0fc436fb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class,'SubscriptionCongrats_') and contains(@class,'formTitle_form-subtitle__')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@class,'SubscriptionCongrats_') and contains(@class,'formTitle_form-subtitle__')]</value>
   </webElementProperties>
</WebElementEntity>
