<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>validityDate</name>
   <tag></tag>
   <elementGuidId>6ce1ddf3-baca-4b84-9d46-8bd9129d370d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'SubscriptionCongrats_validity-date')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>SubscriptionCongrats_validity-date</value>
   </webElementProperties>
</WebElementEntity>
