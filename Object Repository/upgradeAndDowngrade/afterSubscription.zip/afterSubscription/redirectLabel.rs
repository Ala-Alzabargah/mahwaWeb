<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>redirectLabel</name>
   <tag></tag>
   <elementGuidId>e7d0ef3b-c43d-4e5b-a320-88f2fbb34bf3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(@class, 'SubscriptionCongrats_redirect-label')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>SubscriptionCongrats_redirect-label</value>
   </webElementProperties>
</WebElementEntity>
