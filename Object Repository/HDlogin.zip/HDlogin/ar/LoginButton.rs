<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>LoginButton</name>
   <tag></tag>
   <elementGuidId>1bdf8bf5-adf5-4fa2-9760-c8e5dbfb1847</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a//span[text()='تسجيل الدخول']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a//span[text()='تسجيل الدخول']</value>
   </webElementProperties>
</WebElementEntity>
