<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Login</name>
   <tag></tag>
   <elementGuidId>95290676-eed3-4c4c-8416-2f727c806e46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a//span[text()='تسجيل الدخول']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a//span[text()='تسجيل الدخول']</value>
   </webElementProperties>
</WebElementEntity>
