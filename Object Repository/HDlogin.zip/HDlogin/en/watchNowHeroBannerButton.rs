<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>watchNowHeroBannerButton</name>
   <tag></tag>
   <elementGuidId>53472e02-d374-4c24-8deb-75aafcd00258</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//div[contains(text(),&quot;Watch Now&quot;)])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//div[contains(text(),&quot;Watch Now&quot;)])[1]</value>
   </webElementProperties>
</WebElementEntity>
