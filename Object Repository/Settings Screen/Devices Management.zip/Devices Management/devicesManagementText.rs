<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>devicesManagementText</name>
   <tag></tag>
   <elementGuidId>0505536e-2734-40d8-98bf-b0d9baff9ddb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//h1[contains(@class,'PairingCode_form-title__') and text()='Device Management']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h1[contains(@class,'PairingCode_form-title__') and text()='Device Management']</value>
   </webElementProperties>
</WebElementEntity>
