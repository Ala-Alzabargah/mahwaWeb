<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>wrongParingCodeErrorMessage</name>
   <tag></tag>
   <elementGuidId>e9c51a24-e4d8-43ca-9b9f-b671f394f993</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[contains(text(),'The pairing code is either not valid or expired. Please request a new code and try again.')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[contains(text(),'The pairing code is either not valid or expired. Please request a new code and try again.')]</value>
   </webElementProperties>
</WebElementEntity>
