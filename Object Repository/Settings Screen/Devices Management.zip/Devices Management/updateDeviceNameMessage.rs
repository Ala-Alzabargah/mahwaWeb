<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>updateDeviceNameMessage</name>
   <tag></tag>
   <elementGuidId>ad43760d-710a-4340-9598-2f8172735ef3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[contains(text(),'Edits saved successfully') or contains(text(),'تم حفظ التعديلات بنجاح')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[contains(text(),'Edits saved successfully') or contains(text(),'تم حفظ التعديلات بنجاح')]</value>
   </webElementProperties>
</WebElementEntity>
