<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>devicesCurrentlyLinkedText</name>
   <tag></tag>
   <elementGuidId>2143bf9a-3924-45df-910e-f5392d304e09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[contains(text(),'الأجهزة المرتبطة حاليًا بحسابك') or contains(text(),'Currently paired devices to your account') ]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[contains(text(),'الأجهزة المرتبطة حاليًا بحسابك') or contains(text(),'Currently paired devices to your account') ]</value>
   </webElementProperties>
</WebElementEntity>
