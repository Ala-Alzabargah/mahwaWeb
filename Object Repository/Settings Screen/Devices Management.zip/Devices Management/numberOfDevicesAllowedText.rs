<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>numberOfDevicesAllowedText</name>
   <tag></tag>
   <elementGuidId>97ad348e-2564-4195-b33d-554d49a79599</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//p[contains(text(),'You can link unlimited number of devices with your Shahid account')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//p[contains(text(),'You can link unlimited number of devices with your Shahid account')]</value>
   </webElementProperties>
</WebElementEntity>
