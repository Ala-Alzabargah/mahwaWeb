<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>updatedevicenameField</name>
   <tag></tag>
   <elementGuidId>8ead3c11-c7fb-4fb2-a011-f1d179def6d9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[@type='text' and @value and @maxlength=&quot;25&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@type='text' and @value and @maxlength=&quot;25&quot;]</value>
   </webElementProperties>
</WebElementEntity>
