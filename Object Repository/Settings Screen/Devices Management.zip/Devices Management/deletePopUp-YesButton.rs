<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>deletePopUp-YesButton</name>
   <tag></tag>
   <elementGuidId>913fa813-81e2-4d54-9baf-5e886f7adb20</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[contains(text(),'نعم') or contains(text(),'Yes')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[contains(text(),'نعم') or contains(text(),'Yes')]</value>
   </webElementProperties>
</WebElementEntity>
