<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>deleteDoneText</name>
   <tag></tag>
   <elementGuidId>bcd232b3-6fba-4e2c-a14a-26308e5e250f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[contains(text(),'The device has been deleted') or contains(text(),'تم حذف الجهاز')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[contains(text(),'The device has been deleted') or contains(text(),'تم حذف الجهاز')]</value>
   </webElementProperties>
</WebElementEntity>
